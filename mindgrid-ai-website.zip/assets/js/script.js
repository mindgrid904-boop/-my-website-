/**
 * MindGrid AI - Version 2.0 Production Application Logic
 */
(function () {
    'use strict';

    // =========================================================================
    // EmailJS Configuration (Replace placeholders with your EmailJS credentials)
    // =========================================================================
    const EMAILJS_CONFIG = {
        enabled: false, // Set to true after pasting your EmailJS keys below
        publicKey: 'YOUR_EMAILJS_PUBLIC_KEY',
        serviceId: 'YOUR_EMAILJS_SERVICE_ID',
        templateId: 'YOUR_EMAILJS_TEMPLATE_ID',
        recipientEmail: 'mindgrid904@gmail.com'
    };

    const modulesData = {
        1: {
            title: "Module 1: Intro to Digital World & AI (4 Hours)",
            desc: "Foundational digital citizenship, internet basics, and demystifying Artificial Intelligence for daily life.",
            topics: [
                "What is a Computer? Digital Safety & Navigation",
                "Unveiling AI: Human Intelligence vs Machine AI",
                "How AI Learns (Pattern Recognition Analogy)",
                "Interactive 'Is it AI?' Brainstorming & Quiz"
            ],
            badge: "Pilot Module 01 • Foundational"
        },
        2: {
            title: "Module 2: Computational Thinking & Flowcharts (4 Hours)",
            desc: "Developing algorithmic mindset, problem decomposition, and flowchart visualization.",
            topics: [
                "Decomposition: Breaking problems into tiny steps",
                "Pattern Recognition & Abstraction in Daily Life",
                "Designing First Flowcharts with Standard Symbols",
                "Pseudocode Essentials: Writing human code"
            ],
            badge: "Pilot Module 02 • Logic Building"
        },
        3: {
            title: "Module 3: My First Code - Block Programming (4 Hours)",
            desc: "Hands-on visual coding using Scratch / Blockly platforms for interactive stories.",
            topics: [
                "Scratch/Blockly interface, Sprites & Backgrounds",
                "Events, Loops & Conditionals (if/then)",
                "Animating characters & adding sound effects",
                "Mini Project: Interactive Nepali Folk Story / Game"
            ],
            badge: "Pilot Module 03 • Hands-on Coding"
        },
        4: {
            title: "Module 4: Intro to Robotics & Hardware (4 Hours)",
            desc: "Understanding physical computing, sensors, actuators, and mechanical assembly.",
            topics: [
                "What makes a machine a Robot?",
                "Anatomy of SmartBot Kits (Sensors, Motors, Brain)",
                "Basic mechanics: Gears, Wheels & Chassis Assembly",
                "Hands-on assembly challenge with demo kits"
            ],
            badge: "Pilot Module 04 • Robotics Hardware"
        },
        5: {
            title: "Module 5: Robotics Programming & Control (4 Hours)",
            desc: "Connecting visual block code to physical hardware motors and light sensors.",
            topics: [
                "Uploading code to microcontrollers",
                "Motor speed & direction control algorithms",
                "Sensor inputs: Line following & obstacle avoidance",
                "Robot Challenge: Navigate the Classroom Maze"
            ],
            badge: "Pilot Module 05 • Hardware Coding"
        },
        6: {
            title: "Module 6: AI & Creativity - Computer Vision & Bots (4 Hours)",
            desc: "Training machine learning models for image recognition and building simple conversational bots.",
            topics: [
                "How machines see: Computer Vision basics",
                "Training AI model using Teachable Machine",
                "Building a simple keyword-based Chatbot",
                "AI Ethics & Responsible Technology"
            ],
            badge: "Pilot Module 06 • Practical AI"
        },
        7: {
            title: "Module 7: Data Science & Decision Making (4 Hours)",
            desc: "Understanding data collection, visualization, and data-driven AI decision trees.",
            topics: [
                "Types of Data: Numbers, Text & Images",
                "Class survey & data visualization (Bar graphs)",
                "AI Prediction Models based on data patterns",
                "Real-world application: AI in Local Agriculture"
            ],
            badge: "Pilot Module 07 • Data Literacy"
        },
        8: {
            title: "Module 8: Capstone Innovation Project & Showcase (4 Hours)",
            desc: "Students synthesize coding, robotics, and AI knowledge to build and present a final team project.",
            topics: [
                "Brainstorming local problems (Smart Agriculture, Safety)",
                "Project execution & debugging with instructor",
                "Presentation preparation & public speaking",
                "Classroom STEM Exhibition & Certificate Distribution"
            ],
            badge: "Pilot Module 08 • Capstone Showcase"
        }
    };

    const dom = {
        moduleDisplay: document.getElementById('module-display'),
        moduleTabs: document.querySelectorAll('.module-tab'),
        calcTrack: document.getElementById('calc-track'),
        studentSlider: document.getElementById('student-slider'),
        studentValDisplay: document.getElementById('student-count-val'),
        outputScope: document.getElementById('output-scope'),
        outputKits: document.getElementById('output-kits'),
        outputTraining: document.getElementById('output-training'),
        simSensorBtn: document.getElementById('sim-sensor-toggle'),
        simRunBtn: document.getElementById('sim-run-btn'),
        robotVisual: document.getElementById('robot-visual'),
        robotStatusText: document.getElementById('robot-status-text'),
        robotLog: document.getElementById('robot-log'),
        demoForm: document.getElementById('demo-form'),
        formFeedback: document.getElementById('form-feedback'),
        contactSubmitBtn: document.getElementById('contact-submit-btn'),
        modal: document.getElementById('custom-modal'),
        modalClose: document.getElementById('modal-close-btn'),
        mobileBtn: document.getElementById('mobile-menu-btn'),
        mobileMenu: document.getElementById('mobile-menu'),
        mobileLinks: document.querySelectorAll('.mobile-link'),
        backToTopBtn: document.getElementById('back-to-top'),
        revealElements: document.querySelectorAll('.reveal')
    };

    function renderModule(modId) {
        const mod = modulesData[modId];
        if (!mod || !dom.moduleDisplay) return;

        dom.moduleDisplay.innerHTML = '';

        const header = document.createElement('div');
        header.className = 'flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-4 mb-6 gap-2';

        const titleGroup = document.createElement('div');
        const badgeSpan = document.createElement('span');
        badgeSpan.className = 'text-xs font-bold text-cyan-400 uppercase tracking-widest';
        badgeSpan.textContent = mod.badge;

        const heading = document.createElement('h3');
        heading.className = 'font-display text-2xl font-bold text-white mt-1';
        heading.textContent = mod.title;

        titleGroup.appendChild(badgeSpan);
        titleGroup.appendChild(heading);

        const durationPill = document.createElement('span');
        durationPill.className = 'px-3.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-semibold self-start md:self-auto';
        durationPill.textContent = '4 Hours Duration';

        header.appendChild(titleGroup);
        header.appendChild(durationPill);

        const descPara = document.createElement('p');
        descPara.className = 'text-slate-300 text-sm mb-6 leading-relaxed';
        descPara.textContent = mod.desc;

        const topicsWrapper = document.createElement('div');
        topicsWrapper.className = 'space-y-3';

        const topicsLabel = document.createElement('h4');
        topicsLabel.className = 'text-xs font-bold text-slate-400 uppercase tracking-wider';
        topicsLabel.textContent = 'Key Session Topics:';

        const topicsGrid = document.createElement('div');
        topicsGrid.className = 'grid sm:grid-cols-2 gap-3';

        mod.topics.forEach(function (topicText) {
            const card = document.createElement('div');
            card.className = 'p-3.5 rounded-2xl bg-[#070A12] border border-white/[0.08] flex items-start gap-3';

            const icon = document.createElement('i');
            icon.className = 'fa-solid fa-circle-check text-cyan-400 text-sm mt-0.5';
            icon.setAttribute('aria-hidden', 'true');

            const textSpan = document.createElement('span');
            textSpan.className = 'text-xs text-slate-300';
            textSpan.textContent = topicText;

            card.appendChild(icon);
            card.appendChild(textSpan);
            topicsGrid.appendChild(card);
        });

        topicsWrapper.appendChild(topicsLabel);
        topicsWrapper.appendChild(topicsGrid);

        dom.moduleDisplay.appendChild(header);
        dom.moduleDisplay.appendChild(descPara);
        dom.moduleDisplay.appendChild(topicsWrapper);
    }

    function initModuleTabs() {
        if (!dom.moduleTabs.length) return;

        dom.moduleTabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                dom.moduleTabs.forEach(function (t) {
                    t.classList.remove('bg-indigo-600', 'text-white', 'shadow-md', 'shadow-indigo-600/30');
                    t.classList.add('bg-white/[0.05]', 'text-slate-300');
                    t.setAttribute('aria-selected', 'false');
                });

                tab.classList.remove('bg-white/[0.05]', 'text-slate-300');
                tab.classList.add('bg-indigo-600', 'text-white', 'shadow-md', 'shadow-indigo-600/30');
                tab.setAttribute('aria-selected', 'true');

                const modId = tab.getAttribute('data-module');
                renderModule(modId);
            });
        });
    }

    function updateCalculator() {
        if (!dom.studentSlider) return;

        const count = parseInt(dom.studentSlider.value, 10);
        if (dom.studentValDisplay) {
            dom.studentValDisplay.textContent = `${count} Students`;
        }

        const kits = Math.ceil(count / 10);
        const teachers = Math.max(1, Math.ceil(count / 60));

        if (dom.outputScope && dom.calcTrack) {
            dom.outputScope.textContent = dom.calcTrack.value === 'pilot'
                ? '32-Hr Pilot (Pilot Schools)'
                : 'Full K–12 Curriculum';
        }
        if (dom.outputKits) {
            dom.outputKits.textContent = `${kits} SmartKits`;
        }
        if (dom.outputTraining) {
            dom.outputTraining.textContent = `${teachers} Certified Teacher${teachers > 1 ? 's' : ''}`;
        }
    }

    function initCalculator() {
        if (dom.studentSlider) {
            dom.studentSlider.addEventListener('input', updateCalculator);
        }
        if (dom.calcTrack) {
            dom.calcTrack.addEventListener('change', updateCalculator);
        }
    }

    function initSimulator() {
        let isObstacle = false;

        if (dom.simSensorBtn) {
            dom.simSensorBtn.addEventListener('click', function () {
                isObstacle = !isObstacle;
                dom.simSensorBtn.setAttribute('aria-pressed', String(isObstacle));

                if (isObstacle) {
                    dom.simSensorBtn.textContent = 'Obstacle Detected (15cm)';
                    dom.simSensorBtn.classList.remove('bg-emerald-500/20', 'text-emerald-300', 'border-emerald-500/30');
                    dom.simSensorBtn.classList.add('bg-rose-500/20', 'text-rose-300', 'border-rose-500/30');
                } else {
                    dom.simSensorBtn.textContent = 'Clear Path';
                    dom.simSensorBtn.classList.remove('bg-rose-500/20', 'text-rose-300', 'border-rose-500/30');
                    dom.simSensorBtn.classList.add('bg-emerald-500/20', 'text-emerald-300', 'border-emerald-500/30');
                }
            });
        }

        if (dom.simRunBtn) {
            dom.simRunBtn.addEventListener('click', function () {
                if (dom.robotStatusText) {
                    dom.robotStatusText.textContent = 'Status: Executing Code...';
                }
                if (dom.robotVisual) {
                    dom.robotVisual.classList.add('scale-110');
                }

                setTimeout(function () {
                    if (dom.robotVisual) {
                        dom.robotVisual.classList.remove('scale-110');
                    }
                    if (isObstacle) {
                        if (dom.robotStatusText) {
                            dom.robotStatusText.textContent = 'Status: Obstacle Detected! Turning Right';
                            dom.robotStatusText.className = 'text-sm font-bold text-amber-400 font-mono mb-1';
                        }
                        if (dom.robotLog) {
                            dom.robotLog.textContent = 'Sensor: 15cm | Action: Motor_Left(100), Motor_Right(0)';
                        }
                    } else {
                        if (dom.robotStatusText) {
                            dom.robotStatusText.textContent = 'Status: Moving Forward (Smooth Patrol)';
                            dom.robotStatusText.className = 'text-sm font-bold text-cyan-400 font-mono mb-1';
                        }
                        if (dom.robotLog) {
                            dom.robotLog.textContent = 'Sensor: > 50cm | Action: Dual_Motor_Speed(80%)';
                        }
                    }
                }, 600);
            });
        }
    }

    function setFormStatus(message, type) {
        if (!dom.formFeedback) return;
        dom.formFeedback.textContent = message;
        dom.formFeedback.className = 'text-xs rounded-xl p-3 border';

        if (type === 'error') {
            dom.formFeedback.classList.add('bg-rose-500/15', 'border-rose-500/30', 'text-rose-300');
        } else {
            dom.formFeedback.classList.add('bg-emerald-500/15', 'border-emerald-500/30', 'text-emerald-300');
        }
        dom.formFeedback.classList.remove('hidden');
    }

    function closeModal() {
        if (dom.modal) {
            dom.modal.classList.add('hidden');
        }
    }

    function initFormAndModal() {
        if (dom.demoForm && dom.modal) {
            dom.demoForm.addEventListener('submit', function (e) {
                e.preventDefault();

                const submitBtn = dom.contactSubmitBtn;
                const originalBtnHtml = submitBtn ? submitBtn.innerHTML : '';

                if (submitBtn) {
                    submitBtn.disabled = true;
                    submitBtn.textContent = 'Sending Request...';
                }

                if (EMAILJS_CONFIG.enabled && typeof window.emailjs !== 'undefined') {
                    window.emailjs.init(EMAILJS_CONFIG.publicKey);
                    window.emailjs.sendForm(
                        EMAILJS_CONFIG.serviceId,
                        EMAILJS_CONFIG.templateId,
                        dom.demoForm
                    ).then(function () {
                        dom.modal.classList.remove('hidden');
                        dom.demoForm.reset();
                        if (dom.formFeedback) dom.formFeedback.classList.add('hidden');
                        if (dom.modalClose) dom.modalClose.focus();
                    }).catch(function () {
                        setFormStatus(
                            'Unable to send automatically right now. Please email us directly at mindgrid904@gmail.com.',
                            'error'
                        );
                    }).finally(function () {
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.innerHTML = originalBtnHtml;
                        }
                    });
                } else {
                    setTimeout(function () {
                        dom.modal.classList.remove('hidden');
                        dom.demoForm.reset();
                        if (dom.formFeedback) dom.formFeedback.classList.add('hidden');
                        if (submitBtn) {
                            submitBtn.disabled = false;
                            submitBtn.innerHTML = originalBtnHtml;
                        }
                        if (dom.modalClose) dom.modalClose.focus();
                    }, 350);
                }
            });
        }

        if (dom.modalClose) {
            dom.modalClose.addEventListener('click', closeModal);
        }

        if (dom.modal) {
            dom.modal.addEventListener('click', function (e) {
                if (e.target === dom.modal) {
                    closeModal();
                }
            });

            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && !dom.modal.classList.contains('hidden')) {
                    closeModal();
                }
            });
        }
    }

    function initMobileMenu() {
        if (dom.mobileBtn && dom.mobileMenu) {
            dom.mobileBtn.addEventListener('click', function () {
                const isHidden = dom.mobileMenu.classList.toggle('hidden');
                dom.mobileBtn.setAttribute('aria-expanded', String(!isHidden));
            });

            dom.mobileLinks.forEach(function (link) {
                link.addEventListener('click', function () {
                    dom.mobileMenu.classList.add('hidden');
                    dom.mobileBtn.setAttribute('aria-expanded', 'false');
                });
            });
        }
    }

    function initScrollEnhancements() {
        if ('IntersectionObserver' in window && dom.revealElements.length) {
            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12 });

            dom.revealElements.forEach(function (el) {
                observer.observe(el);
            });
        } else {
            dom.revealElements.forEach(function (el) {
                el.classList.add('is-visible');
            });
        }

        if (dom.backToTopBtn) {
            window.addEventListener('scroll', function () {
                if (window.scrollY > 450) {
                    dom.backToTopBtn.classList.add('is-visible');
                } else {
                    dom.backToTopBtn.classList.remove('is-visible');
                }
            }, { passive: true });

            dom.backToTopBtn.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }
    }

    window.addEventListener('DOMContentLoaded', function () {
        initModuleTabs();
        initCalculator();
        initSimulator();
        initFormAndModal();
        initMobileMenu();
        initScrollEnhancements();

        renderModule(1);
        updateCalculator();
    });
})();
